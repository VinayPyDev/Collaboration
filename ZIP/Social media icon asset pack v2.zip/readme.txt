------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Thank you for purchasing my pixel art style social media icon assetpack.

This pack contains handcrafted pixel-art icons inspired by modern social media and online platforms, designed for:

-Video game projects
-UIs
-Streaming overlays
-Websites
-and other creative projects


ALL icons/assets were created by myself without the use of AI.

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Included assets:

-Pixel-art social media inspired icons
-Multiple export sizes
-PNG files with transparent backgrounds
-GIF files of the animations
-spritesheets for the animations

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
License

You may:

Use these assets in personal projects
Use these assets in commercial projects
Modify/edit the assets
Use them in games, apps, videos, streams, and websites

You may NOT:

Resell or redistribute the original files
Claim the assets as your own work
claim the assets as your own or redistribute the assets without modifying them significantly
(to the point that they are not obvious edits of the originals)
Repackage the assets as another asset pack
use these assets to train an AI model or even just uploading the assets to an AI langauge model

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Extra notes:

The assets included in this pack are original pixel-art illustrations created independently and are intended as transformative artistic recreations inspired by recognizable online platforms and internet culture.
These assets were designed for decorative,
interface,
mockup,
and entertainment purposes only,
and are not intended to function as official brand assets,
replacements for official logos,
or representations of endorsement,
sponsorship,
or affiliation with any company or trademark holder.

If you encounter issues or have questions, feel free to contact me through the storefront or platform where you obtained this pack.

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
